package com.firstcry.pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;

public class LoginPage extends BasePage {

    private static final Logger logger = LogManager.getLogger(LoginPage.class);

    // ── Locators ──────────────────────────────────────────────────────────────
    private final By mobileOrEmailField = By.cssSelector("input[type='tel'], input[name='mobile'], input[placeholder*='Mobile'], input[placeholder*='Email']");
    private final By passwordField      = By.cssSelector("input[type='password']");
    private final By continueButton     = By.cssSelector("button.continue-btn, button[type='submit']");
    private final By loginButton        = By.cssSelector("button.login-btn, button[type='submit']");
    private final By errorMessage       = By.cssSelector(".error-msg, .alert-error, span.error");
    private final By welcomeUser        = By.cssSelector(".user-name, .welcome-msg, .account-name");
    private final By forgotPasswordLink = By.cssSelector("a[href*='forgot'], .forgot-pwd");

    // ── Actions ───────────────────────────────────────────────────────────────

    public void enterMobileOrEmail(String value) {
        logger.info("Entering mobile/email: {}", value);
        type(mobileOrEmailField, value);
    }

    public void clickContinue() {
        logger.info("Clicking Continue");
        click(continueButton);
    }

    public void enterPassword(String password) {
        logger.info("Entering password");
        type(passwordField, password);
    }

    public void clickLogin() {
        logger.info("Clicking Login button");
        click(loginButton);
    }

    public void loginWith(String mobileOrEmail, String password) {
        enterMobileOrEmail(mobileOrEmail);
        clickContinue();
        enterPassword(password);
        clickLogin();
    }

    public boolean isLoggedIn() {
        return isDisplayed(welcomeUser);
    }

    public String getErrorMessage() {
        return getText(errorMessage);
    }

    public boolean isErrorDisplayed() {
        return isDisplayed(errorMessage);
    }

    public void clickForgotPassword() {
        click(forgotPasswordLink);
    }
}
