package com.firstcry.pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class CartPage extends BasePage {

    private static final Logger logger = LogManager.getLogger(CartPage.class);

    // ── Locators ──────────────────────────────────────────────────────────────
    private final By cartItems          = By.cssSelector(".cart-item, .bag-item, .cart-product");
    private final By removeItemButtons  = By.cssSelector(".remove-item, .delete-item, button.remove");
    private final By cartTotal          = By.cssSelector(".cart-total, .order-total, .total-price");
    private final By proceedToCheckout  = By.cssSelector("button.checkout-btn, .proceed-btn, a.checkout");
    private final By emptyCartMessage   = By.cssSelector(".empty-cart, .cart-empty-msg");
    private final By cartItemCount      = By.cssSelector(".cart-count, .item-count");
    private final By couponField        = By.cssSelector("input.coupon-input, input[placeholder*='coupon'], input[placeholder*='Coupon']");
    private final By applyCouponButton  = By.cssSelector("button.apply-coupon, .apply-btn");
    private final By couponMessage      = By.cssSelector(".coupon-msg, .coupon-success, .coupon-error");
    private final By itemQuantityPlus   = By.cssSelector(".qty-plus, button.increase-qty");
    private final By itemQuantityMinus  = By.cssSelector(".qty-minus, button.decrease-qty");

    // ── Actions ───────────────────────────────────────────────────────────────

    public boolean isCartPageLoaded() {
        return driver.getCurrentUrl().contains("cart") || isDisplayed(cartItems) || isDisplayed(emptyCartMessage);
    }

    public int getCartItemCount() {
        List<WebElement> items = driver.findElements(cartItems);
        logger.info("Cart items found: {}", items.size());
        return items.size();
    }

    public boolean isCartEmpty() {
        return isDisplayed(emptyCartMessage);
    }

    public String getCartTotal() {
        return getText(cartTotal);
    }

    public void removeFirstItem() {
        logger.info("Removing first item from cart");
        List<WebElement> buttons = driver.findElements(removeItemButtons);
        if (!buttons.isEmpty()) {
            buttons.get(0).click();
        }
    }

    public void clickProceedToCheckout() {
        logger.info("Clicking Proceed to Checkout");
        click(proceedToCheckout);
    }

    public void applyCoupon(String couponCode) {
        logger.info("Applying coupon: {}", couponCode);
        type(couponField, couponCode);
        click(applyCouponButton);
    }

    public String getCouponMessage() {
        return getText(couponMessage);
    }

    public void increaseItemQuantity() {
        logger.info("Increasing item quantity");
        click(itemQuantityPlus);
    }

    public void decreaseItemQuantity() {
        logger.info("Decreasing item quantity");
        click(itemQuantityMinus);
    }
}
