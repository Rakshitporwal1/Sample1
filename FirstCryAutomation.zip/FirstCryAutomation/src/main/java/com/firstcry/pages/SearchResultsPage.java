package com.firstcry.pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class SearchResultsPage extends BasePage {

    private static final Logger logger = LogManager.getLogger(SearchResultsPage.class);

    // ── Locators ──────────────────────────────────────────────────────────────
    private final By productCards      = By.cssSelector(".product-box, .product-card, .prod-info-box");
    private final By productTitles     = By.cssSelector(".product-box .prod-name, .product-card .title, .prod-info-box .title");
    private final By resultsCount      = By.cssSelector(".result-count, .products-count, .showing-results");
    private final By sortDropdown      = By.cssSelector(".sort-by select, select[name='sort']");
    private final By filterSection     = By.cssSelector(".filter-section, .filters-panel, .left-filter");
    private final By noResultsMessage  = By.cssSelector(".no-result, .no-products, .empty-search");
    private final By firstProduct      = By.cssSelector(".product-box:first-child a, .product-card:first-child a");
    private final By priceFilter       = By.cssSelector(".price-filter, input[name='price']");

    // ── Actions ───────────────────────────────────────────────────────────────

    public boolean areResultsDisplayed() {
        List<WebElement> products = driver.findElements(productCards);
        logger.info("Products found: {}", products.size());
        return !products.isEmpty();
    }

    public int getResultCount() {
        return driver.findElements(productCards).size();
    }

    public String getResultsCountText() {
        return getText(resultsCount);
    }

    public void clickFirstProduct() {
        logger.info("Clicking first product in results");
        click(firstProduct);
    }

    public boolean isNoResultsMessageDisplayed() {
        return isDisplayed(noResultsMessage);
    }

    public boolean isFilterSectionDisplayed() {
        return isDisplayed(filterSection);
    }

    public List<WebElement> getAllProductTitles() {
        return driver.findElements(productTitles);
    }

    public boolean areResultsRelatedTo(String keyword) {
        List<WebElement> titles = getAllProductTitles();
        return titles.stream()
                .anyMatch(t -> t.getText().toLowerCase().contains(keyword.toLowerCase()));
    }
}
