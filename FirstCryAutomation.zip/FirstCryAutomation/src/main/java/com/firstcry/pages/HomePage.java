package com.firstcry.pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;

public class HomePage extends BasePage {

    private static final Logger logger = LogManager.getLogger(HomePage.class);

    // ── Locators ──────────────────────────────────────────────────────────────
    private final By searchBox        = By.id("search-bar-input");
    private final By searchButton     = By.cssSelector("button.search-btn, button[type='submit']");
    private final By loginLink        = By.cssSelector("a[href*='login'], .login-link, .user-icon");
    private final By logo             = By.cssSelector(".fc-logo img, a.logo img, img[alt*='FirstCry']");
    private final By cartIcon         = By.cssSelector(".cart-icon, a[href*='cart']");
    private final By categoryMenu     = By.cssSelector(".nav-category, .main-nav a");
    private final By closePopup       = By.cssSelector(".modal-close, .popup-close, button[aria-label='Close']");

    // ── Actions ───────────────────────────────────────────────────────────────

    public void openHomePage() {
        logger.info("Navigating to FirstCry home page");
        driver.get("https://www.firstcry.com");
        dismissPopupIfPresent();
    }

    public boolean isHomePageLoaded() {
        return isDisplayed(logo) || driver.getTitle().toLowerCase().contains("firstcry");
    }

    public void searchFor(String keyword) {
        logger.info("Searching for: {}", keyword);
        type(searchBox, keyword);
        click(searchButton);
    }

    public void clickLoginLink() {
        logger.info("Clicking Login link");
        click(loginLink);
    }

    public void clickCartIcon() {
        logger.info("Clicking Cart icon");
        click(cartIcon);
    }

    public String getPageTitle() {
        return driver.getTitle();
    }

    private void dismissPopupIfPresent() {
        try {
            Thread.sleep(1500);
            if (isDisplayed(closePopup)) {
                jsClick(closePopup);
                logger.info("Dismissed popup/modal.");
            }
        } catch (Exception ignored) {}
    }
}
