package com.firstcry.pages;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;

public class ProductPage extends BasePage {

    private static final Logger logger = LogManager.getLogger(ProductPage.class);

    // ── Locators ──────────────────────────────────────────────────────────────
    private final By productTitle       = By.cssSelector("h1.product-title, h1.prod-name, .prod-detail h1");
    private final By productPrice       = By.cssSelector(".product-price, .final-price, .sp span");
    private final By addToCartButton    = By.cssSelector("button.add-to-cart, .add-cart-btn, button[data-action='addtocart']");
    private final By buyNowButton       = By.cssSelector("button.buy-now, .buy-now-btn");
    private final By pinCodeField       = By.cssSelector("input.pincode-input, input[placeholder*='Pincode'], input[placeholder*='Pin Code']");
    private final By checkPincodeBtn    = By.cssSelector("button.check-pincode, .check-availability");
    private final By deliveryMessage    = By.cssSelector(".delivery-msg, .delivery-info, .pincode-msg");
    private final By productImages      = By.cssSelector(".product-images img, .prod-img-container img");
    private final By productDescription = By.cssSelector(".product-desc, .description-section, #description");
    private final By ratingStars        = By.cssSelector(".rating-stars, .star-rating .filled");
    private final By wishlistButton     = By.cssSelector(".wishlist-btn, button.add-wishlist, .wish-icon");
    private final By cartSuccessMsg     = By.cssSelector(".cart-success, .added-to-cart-msg, .success-toast");
    private final By sizeSelector       = By.cssSelector(".size-option, .size-btn, select[name='size']");
    private final By quantityField      = By.cssSelector("input.qty-input, input[name='quantity']");

    // ── Actions ───────────────────────────────────────────────────────────────

    public String getProductTitle() {
        return getText(productTitle);
    }

    public String getProductPrice() {
        return getText(productPrice);
    }

    public boolean isProductPageLoaded() {
        return isDisplayed(productTitle) && isDisplayed(addToCartButton);
    }

    public void clickAddToCart() {
        logger.info("Clicking Add to Cart");
        scrollToElement(addToCartButton);
        click(addToCartButton);
    }

    public void clickBuyNow() {
        logger.info("Clicking Buy Now");
        click(buyNowButton);
    }

    public void checkDeliveryByPincode(String pincode) {
        logger.info("Checking delivery for pincode: {}", pincode);
        type(pinCodeField, pincode);
        click(checkPincodeBtn);
    }

    public String getDeliveryMessage() {
        return getText(deliveryMessage);
    }

    public boolean isAddToCartSuccessful() {
        return isDisplayed(cartSuccessMsg);
    }

    public void clickWishlist() {
        logger.info("Clicking Wishlist button");
        click(wishlistButton);
    }

    public boolean isWishlistButtonDisplayed() {
        return isDisplayed(wishlistButton);
    }
}
