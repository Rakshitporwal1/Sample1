@HomePage
Feature: FirstCry Home Page

  Background:
    Given I open the FirstCry home page

  @Smoke
  Scenario: Verify FirstCry home page loads successfully
    Then the FirstCry home page should be displayed
    And the page title should contain "FirstCry"

  @Smoke
  Scenario: Verify navigation to login from home page
    When I click on the login link on home page
    Then the page title should contain "Login"

  @Regression
  Scenario: Verify cart icon is accessible from home page
    When I click on the cart icon
    Then the cart page should be loaded
