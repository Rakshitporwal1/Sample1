@Cart
Feature: FirstCry Shopping Cart

  @Smoke
  Scenario: View empty cart page
    Given I open the FirstCry home page
    When I navigate to the cart page
    Then the cart page should be loaded

  @Smoke
  Scenario: Add product to cart and verify cart count
    Given I am on the FirstCry home page
    When I search for "baby oil"
    And I click on the first product in results
    Then the product detail page should be loaded
    When I click Add to Cart on the product page
    And I navigate to the cart page
    Then the cart page should be loaded
    And the cart total should be visible

  @Regression
  Scenario: Remove item from cart
    Given I am on the FirstCry home page
    When I search for "baby powder"
    And I click on the first product in results
    When I click Add to Cart on the product page
    And I navigate to the cart page
    When I remove the first item from the cart
    Then the cart should be empty

  @Regression
  Scenario: Apply an invalid coupon code
    Given I am on the FirstCry home page
    When I search for "diapers"
    And I click on the first product in results
    When I click Add to Cart on the product page
    And I navigate to the cart page
    When I apply coupon "INVALIDCOUPON123"
    Then a coupon message should be shown
