@Login
Feature: FirstCry Login

  @Smoke
  Scenario: Successful login with valid credentials
    Given I am on the FirstCry login page
    When I login with "9876543210" and "ValidPass@123"
    Then the user should be logged in successfully

  @Regression
  Scenario: Login with invalid password shows error
    Given I am on the FirstCry login page
    When I enter mobile number or email "9876543210"
    And I click Continue
    And I enter password "WrongPassword"
    And I click Login
    Then an error message should be displayed

  @Regression
  Scenario: Login with unregistered mobile shows error
    Given I am on the FirstCry login page
    When I enter mobile number or email "0000000000"
    And I click Continue
    Then an error message should be displayed

  @Regression
  Scenario Outline: Login attempts with multiple invalid credentials
    Given I am on the FirstCry login page
    When I login with "<mobile>" and "<password>"
    Then an error message should be displayed

    Examples:
      | mobile     | password      |
      | 1234567890 | wrongpass     |
      | 9999999999 | invalidPass@1 |
