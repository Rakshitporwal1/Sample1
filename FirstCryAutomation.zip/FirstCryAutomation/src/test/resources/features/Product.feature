@Product
Feature: FirstCry Product Detail Page

  Background:
    Given I am on the FirstCry home page
    When I search for "diapers"
    And I click on the first product in results

  @Smoke
  Scenario: Product detail page displays title and price
    Then the product detail page should be loaded
    And the product title should be visible
    And the product price should be visible

  @Smoke
  Scenario: Add to Cart button is functional
    Then the product detail page should be loaded
    When I click Add to Cart on the product page

  @Regression
  Scenario: Check delivery availability by pincode
    Then the product detail page should be loaded
    When I check delivery availability for pincode "400001"
    Then a delivery message should be displayed

  @Regression
  Scenario: Wishlist button is visible on product page
    Then the product detail page should be loaded
    Then the wishlist button should be visible
