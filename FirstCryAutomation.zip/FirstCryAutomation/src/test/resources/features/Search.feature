@Search
Feature: FirstCry Product Search

  Background:
    Given I am on the FirstCry home page

  @Smoke
  Scenario: Search for a valid product returns results
    When I search for "diapers"
    Then search results should be displayed
    And search results should contain products related to "diapers"

  @Smoke
  Scenario: Search for baby clothes returns results
    When I search for "baby clothes"
    Then search results should be displayed
    And at least 5 products should be shown

  @Regression
  Scenario: Search for an invalid keyword shows no results message
    When I search for "xyznonexistentproduct12345"
    Then no results message should be displayed

  @Regression
  Scenario Outline: Search for multiple product categories
    When I search for "<keyword>"
    Then search results should be displayed

    Examples:
      | keyword        |
      | baby shoes     |
      | pram           |
      | feeding bottle |
      | toys           |

  @Regression
  Scenario: Clicking on a search result opens product page
    When I search for "baby shampoo"
    And I click on the first product in results
    Then the product detail page should be loaded
