package com.firstcry.stepdefs;

import com.firstcry.pages.ProductPage;
import io.cucumber.java.en.*;
import org.testng.Assert;

public class ProductSteps {

    private final ProductPage productPage = new ProductPage();

    @Then("the product detail page should be loaded")
    public void theProductDetailPageShouldBeLoaded() {
        Assert.assertTrue(productPage.isProductPageLoaded(),
                "Product detail page did not load correctly.");
    }

    @Then("the product title should be visible")
    public void theProductTitleShouldBeVisible() {
        String title = productPage.getProductTitle();
        Assert.assertFalse(title.isEmpty(), "Product title is empty.");
    }

    @Then("the product price should be visible")
    public void theProductPriceShouldBeVisible() {
        String price = productPage.getProductPrice();
        Assert.assertFalse(price.isEmpty(), "Product price is empty.");
    }

    @When("I click Add to Cart on the product page")
    public void iClickAddToCart() {
        productPage.clickAddToCart();
    }

    @When("I click Buy Now on the product page")
    public void iClickBuyNow() {
        productPage.clickBuyNow();
    }

    @When("I check delivery availability for pincode {string}")
    public void iCheckDeliveryAvailabilityForPincode(String pincode) {
        productPage.checkDeliveryByPincode(pincode);
    }

    @Then("a delivery message should be displayed")
    public void aDeliveryMessageShouldBeDisplayed() {
        String msg = productPage.getDeliveryMessage();
        Assert.assertFalse(msg.isEmpty(), "Delivery message is empty.");
    }

    @When("I click the wishlist button")
    public void iClickTheWishlistButton() {
        productPage.clickWishlist();
    }

    @Then("the wishlist button should be visible")
    public void theWishlistButtonShouldBeVisible() {
        Assert.assertTrue(productPage.isWishlistButtonDisplayed(), "Wishlist button not visible.");
    }
}
