package com.firstcry.stepdefs;

import com.firstcry.pages.HomePage;
import com.firstcry.pages.SearchResultsPage;
import io.cucumber.java.en.*;
import org.testng.Assert;

public class SearchSteps {

    private final HomePage          homePage    = new HomePage();
    private final SearchResultsPage resultsPage = new SearchResultsPage();

    @Given("I am on the FirstCry home page")
    public void iAmOnTheFirstCryHomePage() {
        homePage.openHomePage();
    }

    @When("I search for {string}")
    public void iSearchFor(String keyword) {
        homePage.searchFor(keyword);
    }

    @Then("search results should be displayed")
    public void searchResultsShouldBeDisplayed() {
        Assert.assertTrue(resultsPage.areResultsDisplayed(),
                "No search results were displayed.");
    }

    @Then("search results should contain products related to {string}")
    public void searchResultsShouldContainProductsRelatedTo(String keyword) {
        Assert.assertTrue(resultsPage.areResultsRelatedTo(keyword),
                "Results do not appear related to: " + keyword);
    }

    @Then("no results message should be displayed")
    public void noResultsMessageShouldBeDisplayed() {
        Assert.assertTrue(resultsPage.isNoResultsMessageDisplayed(),
                "No 'no results' message was shown.");
    }

    @Then("at least {int} products should be shown")
    public void atLeastProductsShouldBeShown(int count) {
        Assert.assertTrue(resultsPage.getResultCount() >= count,
                "Expected at least " + count + " products, found: " + resultsPage.getResultCount());
    }

    @When("I click on the first product in results")
    public void iClickOnTheFirstProductInResults() {
        resultsPage.clickFirstProduct();
    }
}
