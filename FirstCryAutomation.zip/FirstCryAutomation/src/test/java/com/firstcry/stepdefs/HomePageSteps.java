package com.firstcry.stepdefs;

import com.firstcry.pages.HomePage;
import io.cucumber.java.en.*;
import org.testng.Assert;

public class HomePageSteps {

    private final HomePage homePage = new HomePage();

    @Given("I open the FirstCry home page")
    public void iOpenTheFirstCryHomePage() {
        homePage.openHomePage();
    }

    @Then("the FirstCry home page should be displayed")
    public void theFirstCryHomePageShouldBeDisplayed() {
        Assert.assertTrue(homePage.isHomePageLoaded(),
                "Home page was not loaded. Title was: " + homePage.getPageTitle());
    }

    @Then("the page title should contain {string}")
    public void thePageTitleShouldContain(String expectedText) {
        Assert.assertTrue(homePage.getPageTitle().toLowerCase().contains(expectedText.toLowerCase()),
                "Page title does not contain '" + expectedText + "'. Actual: " + homePage.getPageTitle());
    }

    @When("I click on the login link on home page")
    public void iClickOnTheLoginLink() {
        homePage.clickLoginLink();
    }

    @When("I click on the cart icon")
    public void iClickOnTheCartIcon() {
        homePage.clickCartIcon();
    }
}
