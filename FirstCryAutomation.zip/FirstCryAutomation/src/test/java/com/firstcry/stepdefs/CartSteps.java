package com.firstcry.stepdefs;

import com.firstcry.pages.CartPage;
import com.firstcry.pages.HomePage;
import io.cucumber.java.en.*;
import org.testng.Assert;

public class CartSteps {

    private final CartPage  cartPage = new CartPage();
    private final HomePage  homePage = new HomePage();

    @When("I navigate to the cart page")
    public void iNavigateToTheCartPage() {
        homePage.clickCartIcon();
    }

    @Then("the cart page should be loaded")
    public void theCartPageShouldBeLoaded() {
        Assert.assertTrue(cartPage.isCartPageLoaded(), "Cart page did not load.");
    }

    @Then("the cart should be empty")
    public void theCartShouldBeEmpty() {
        Assert.assertTrue(cartPage.isCartEmpty(), "Cart is not empty.");
    }

    @Then("the cart should have {int} item(s)")
    public void theCartShouldHaveItems(int expectedCount) {
        Assert.assertEquals(cartPage.getCartItemCount(), expectedCount,
                "Cart item count mismatch.");
    }

    @Then("the cart total should be visible")
    public void theCartTotalShouldBeVisible() {
        String total = cartPage.getCartTotal();
        Assert.assertFalse(total.isEmpty(), "Cart total is not visible.");
    }

    @When("I remove the first item from the cart")
    public void iRemoveTheFirstItemFromTheCart() {
        cartPage.removeFirstItem();
    }

    @When("I apply coupon {string}")
    public void iApplyCoupon(String couponCode) {
        cartPage.applyCoupon(couponCode);
    }

    @Then("a coupon message should be shown")
    public void aCouponMessageShouldBeShown() {
        String msg = cartPage.getCouponMessage();
        Assert.assertFalse(msg.isEmpty(), "Coupon message is empty.");
    }

    @When("I click Proceed to Checkout")
    public void iClickProceedToCheckout() {
        cartPage.clickProceedToCheckout();
    }
}
