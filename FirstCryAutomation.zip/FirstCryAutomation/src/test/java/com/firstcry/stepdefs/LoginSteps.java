package com.firstcry.stepdefs;

import com.firstcry.pages.HomePage;
import com.firstcry.pages.LoginPage;
import io.cucumber.java.en.*;
import org.testng.Assert;

public class LoginSteps {

    private final HomePage homePage   = new HomePage();
    private final LoginPage loginPage = new LoginPage();

    @Given("I am on the FirstCry login page")
    public void iAmOnTheFirstCryLoginPage() {
        homePage.openHomePage();
        homePage.clickLoginLink();
    }

    @When("I enter mobile number or email {string}")
    public void iEnterMobileNumberOrEmail(String value) {
        loginPage.enterMobileOrEmail(value);
    }

    @And("I click Continue")
    public void iClickContinue() {
        loginPage.clickContinue();
    }

    @And("I enter password {string}")
    public void iEnterPassword(String password) {
        loginPage.enterPassword(password);
    }

    @And("I click Login")
    public void iClickLogin() {
        loginPage.clickLogin();
    }

    @When("I login with {string} and {string}")
    public void iLoginWith(String mobileOrEmail, String password) {
        loginPage.loginWith(mobileOrEmail, password);
    }

    @Then("the user should be logged in successfully")
    public void theUserShouldBeLoggedInSuccessfully() {
        Assert.assertTrue(loginPage.isLoggedIn(), "User is not logged in.");
    }

    @Then("an error message should be displayed")
    public void anErrorMessageShouldBeDisplayed() {
        Assert.assertTrue(loginPage.isErrorDisplayed(),
                "No error message displayed for invalid credentials.");
    }

    @Then("the login error message should be {string}")
    public void theLoginErrorMessageShouldBe(String expectedMsg) {
        Assert.assertEquals(loginPage.getErrorMessage(), expectedMsg);
    }
}
